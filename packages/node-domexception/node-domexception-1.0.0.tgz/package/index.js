module.exports = globalThis.DOMException;
